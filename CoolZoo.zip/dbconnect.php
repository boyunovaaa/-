<?php
// Создаем соединение с БД
$servername = "std-mysql";
$database = "std_1999_zoo3";
$username = "std_1999_zoo3";
$password = "12345678";
$conn = mysqli_connect($servername, $username, $password, $database);
?>